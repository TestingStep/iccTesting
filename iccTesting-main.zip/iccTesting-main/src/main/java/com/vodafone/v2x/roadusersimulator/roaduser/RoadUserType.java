package com.vodafone.v2x.roadusersimulator.roaduser;

public enum RoadUserType {
    PEDESTRIAN,
    BICYCLIST,
    PASSENGER_CAR
}
